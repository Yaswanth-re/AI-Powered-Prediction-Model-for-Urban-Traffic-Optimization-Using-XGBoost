"""Reproducible experiments: next-h-hour traffic volume forecasting, Metro Interstate (I-94 WB) dataset.
Usage: python run_experiments.py <metro_csv> <outdir>
All reported numbers come from this script (results.json + CSV tables)."""
import sys, json, warnings, numpy as np, pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import Ridge
from sklearn.model_selection import TimeSeriesSplit, RandomizedSearchCV
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import xgboost as xgb, shap, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
warnings.filterwarnings("ignore")
src, out = sys.argv[1], sys.argv[2]
SEED = 42; rng = np.random.default_rng(SEED)
R = {}

# ---------- load & clean ----------
raw = pd.read_csv(src, parse_dates=["date_time"])
R["raw_rows"] = len(raw)
R["raw_date_min"], R["raw_date_max"] = str(raw.date_time.min()), str(raw.date_time.max())
R["raw_duplicate_timestamps"] = int(raw.date_time.duplicated().sum())
R["raw_missing_holiday_label_rows"] = int(raw.holiday.isna().sum())
R["raw_temp_zero_rows"] = int((raw.temp <= 0).sum())
R["raw_rain_gt100_rows"] = int((raw.rain_1h > 100).sum())
dup = raw[raw.date_time.duplicated(keep=False)].groupby("date_time").traffic_volume.nunique()
R["dup_timestamps_with_conflicting_volume"] = int((dup > 1).sum())
raw.loc[raw.temp <= 0, "temp"] = np.nan          # 0 K is physically implausible
raw.loc[raw.rain_1h > 100, "rain_1h"] = np.nan   # >100 mm/h implausible (known sensor error)
holiday_dates = set(raw.loc[raw.holiday.notna(), "date_time"].dt.normalize())
g = raw.groupby("date_time").agg(traffic_volume=("traffic_volume", "mean"), temp=("temp", "mean"),
        rain_1h=("rain_1h", "mean"), snow_1h=("snow_1h", "mean"), clouds_all=("clouds_all", "mean"))
full = g.reindex(pd.date_range(g.index.min(), g.index.max(), freq="h"))
R["hourly_grid_len"] = len(full); R["hourly_missing_before_fill"] = int(full.traffic_volume.isna().sum())
# fill only short gaps (<=3 h) by linear interpolation; longer gaps stay missing
full = full.interpolate(limit=3, limit_area="inside")
R["hourly_missing_after_fill"] = int(full.traffic_volume.isna().sum())
full[["rain_1h", "snow_1h"]] = full[["rain_1h", "snow_1h"]].fillna(0.0)
full["temp"] = full["temp"].ffill(limit=24); full["clouds_all"] = full["clouds_all"].ffill(limit=24)
full["temp_c"] = full["temp"] - 273.15

# ---------- features ----------
def cal(idx):
    d = pd.DataFrame(index=idx)
    d["hour"] = idx.hour; d["dow"] = idx.dayofweek; d["month"] = idx.month
    d["is_weekend"] = (d.dow >= 5).astype(int)
    d["is_rush"] = (((d.hour >= 7) & (d.hour <= 9)) | ((d.hour >= 16) & (d.hour <= 18))).astype(int)
    d["is_holiday"] = pd.Series(idx.normalize(), index=idx).isin(holiday_dates).astype(int)
    for n, p in (("hour", 24), ("dow", 7), ("month", 12)):
        d[n + "_sin"] = np.sin(2 * np.pi * d[n] / p); d[n + "_cos"] = np.cos(2 * np.pi * d[n] / p)
    return d
v = full.traffic_volume
def build(h):
    X = pd.DataFrame(index=full.index)
    for k in (0, 1, 2, 3, 6, 12, 24, 168): X[f"lag_{k}"] = v.shift(k)
    for w in (3, 24, 168): X[f"roll_mean_{w}"] = v.rolling(w, min_periods=w).mean()
    X["roll_std_24"] = v.rolling(24, min_periods=24).std()
    for c in ("temp_c", "rain_1h", "snow_1h", "clouds_all"): X[c] = full[c]       # weather observed at origin time
    tgt_idx = full.index + pd.Timedelta(hours=h)
    C = cal(tgt_idx); C.index = full.index; X = X.join(C)                           # calendar of the target hour
    y = v.shift(-h)
    base = pd.DataFrame({"persistence": v, "snaive_24": v.shift(24 - h) if h <= 24 else np.nan,
                         "snaive_168": v.shift(168 - h)}, index=full.index)
    D = X.join(y.rename("y")).join(base)
    D["target_time"] = tgt_idx
    return D.dropna()
CAL = ["hour", "dow", "month", "is_weekend", "is_rush", "is_holiday", "hour_sin", "hour_cos", "dow_sin", "dow_cos", "month_sin", "month_cos"]
WX = ["temp_c", "rain_1h", "snow_1h", "clouds_all"]
LAGS = [c for c in build(1).columns if c.startswith(("lag_", "roll_"))]
FULL = LAGS + WX + CAL
SPLIT_TEST = pd.Timestamp("2017-10-01")
def split(D):
    tr = D[D.target_time < SPLIT_TEST]; te = D[D.target_time >= SPLIT_TEST]
    return tr, te
def met(y, p): return dict(MAE=mean_absolute_error(y, p), RMSE=mean_squared_error(y, p) ** 0.5, R2=r2_score(y, p))

# ---------- models ----------
def tune(model, grid, Xtr, ytr, n_iter):
    cv = TimeSeriesSplit(n_splits=4)
    s = RandomizedSearchCV(model, grid, n_iter=n_iter, cv=cv, scoring="neg_root_mean_squared_error",
                           random_state=SEED, n_jobs=-1)
    s.fit(Xtr, ytr); return s.best_params_
XGB_GRID = dict(n_estimators=[200, 400, 800], max_depth=[3, 4, 6, 8], learning_rate=[0.02, 0.05, 0.1],
                subsample=[0.7, 0.85, 1.0], colsample_bytree=[0.6, 0.8, 1.0], min_child_weight=[1, 5, 10], reg_lambda=[1, 5, 10])
RF_GRID = dict(n_estimators=[100, 200], max_depth=[10, 16, None], min_samples_leaf=[1, 3, 8], max_features=[0.33, 0.6, 1.0])
HORIZONS = [1, 3, 6, 24]
rows, preds_store, params_store, tstats = [], {}, {}, {}
for h in HORIZONS:
    D = build(h); tr, te = split(D)
    tstats[h] = dict(n_train=len(tr), n_test=len(te), train_start=str(tr.target_time.min()), train_end=str(tr.target_time.max()),
                     test_start=str(te.target_time.min()), test_end=str(te.target_time.max()))
    Xtr, ytr, Xte, yte = tr[FULL], tr.y, te[FULL], te.y
    P = {}
    P["Persistence"] = te.persistence.values
    if h <= 24: P["Seasonal naive (24 h)"] = te.snaive_24.values
    P["Seasonal naive (168 h)"] = te.snaive_168.values
    hm = tr.groupby([tr.target_time.dt.dayofweek, tr.target_time.dt.hour]).y.mean()
    P["Historical mean (dow x hour)"] = np.array([hm[(t.dayofweek, t.hour)] for t in te.target_time])
    ridge = make_pipeline(StandardScaler(), Ridge(alpha=10.0)).fit(Xtr, ytr); P["Ridge regression"] = ridge.predict(Xte)
    prf = tune(RandomForestRegressor(random_state=SEED, n_jobs=1), RF_GRID, Xtr, ytr, 4)
    pxg = tune(xgb.XGBRegressor(random_state=SEED, n_jobs=1, tree_method="hist"), XGB_GRID, Xtr, ytr, 12)
    params_store[h] = dict(rf=prf, xgb=pxg)
    rf_p, xg_p = [], []
    for s in range(3):
        rf = RandomForestRegressor(random_state=s, n_jobs=-1, **prf).fit(Xtr, ytr); rf_p.append(rf.predict(Xte))
        xm = xgb.XGBRegressor(random_state=s, n_jobs=-1, tree_method="hist", **pxg).fit(Xtr, ytr); xg_p.append(xm.predict(Xte))
        if s == 0 and h == 1: xgb_h1 = xm
    P["Random forest"] = np.mean(rf_p, 0); P["XGBoost"] = np.mean(xg_p, 0)
    seed_sd = dict(rf_rmse_sd=float(np.std([met(yte, p)["RMSE"] for p in rf_p])), xgb_rmse_sd=float(np.std([met(yte, p)["RMSE"] for p in xg_p])),
                   xgb_mae_sd=float(np.std([met(yte, p)["MAE"] for p in xg_p])), xgb_r2_sd=float(np.std([met(yte, p)["R2"] for p in xg_p])))
    tstats[h].update(seed_sd)
    # train-set fit for overfitting check
    tstats[h]["xgb_train_rmse"] = float(met(ytr, xm.predict(Xtr))["RMSE"]); tstats[h]["rf_train_rmse"] = float(met(ytr, rf.predict(Xtr))["RMSE"])
    for m, p in P.items(): rows.append(dict(horizon_h=h, model=m, **met(yte, p)))
    preds_store[h] = (te.target_time.values, yte.values, P)
res = pd.DataFrame(rows); res.to_csv(f"{out}/table_model_comparison.csv", index=False)
R["horizon_stats"] = tstats; R["best_params"] = params_store

# ---------- block-bootstrap CI: XGB vs RF and vs best baseline (RMSE difference) ----------
def block_boot(y, a, b, L=168, B=500):
    n = len(y); nb = int(np.ceil(n / L)); d = []
    ea, eb = (y - a) ** 2, (y - b) ** 2
    for _ in range(B):
        st = rng.integers(0, n - L, nb); idx = np.concatenate([np.arange(s, s + L) for s in st])[:n]
        d.append(np.sqrt(ea[idx].mean()) - np.sqrt(eb[idx].mean()))
    return [float(np.percentile(d, 2.5)), float(np.percentile(d, 97.5))]
R["bootstrap_rmse_diff_xgb_minus_other"] = {}
for h in HORIZONS:
    _, y, P = preds_store[h]
    R["bootstrap_rmse_diff_xgb_minus_other"][h] = {
        "vs_RF": block_boot(y, P["XGBoost"], P["Random forest"]),
        "vs_Ridge": block_boot(y, P["XGBoost"], P["Ridge regression"]),
        "vs_Seasonal naive (168 h)": block_boot(y, P["XGBoost"], P["Seasonal naive (168 h)"])}

# ---------- ablation (h=1 and h=24), XGBoost with the tuned params ----------
abl = []
for h in (1, 24):
    D = build(h); tr, te = split(D); pxg = params_store[h]["xgb"]
    for name, cols in {"Calendar only": CAL, "Calendar + weather": CAL + WX, "Lags/rolling only": LAGS,
                       "Lags + calendar": LAGS + CAL, "All features": FULL}.items():
        ps = [xgb.XGBRegressor(random_state=s, n_jobs=-1, tree_method="hist", **pxg).fit(tr[cols], tr.y).predict(te[cols]) for s in range(2)]
        abl.append(dict(horizon_h=h, feature_set=name, **met(te.y, np.mean(ps, 0))))
pd.DataFrame(abl).to_csv(f"{out}/table_ablation.csv", index=False)

# ---------- error analysis h=1 ----------
t, y, P = preds_store[1]; p = P["XGBoost"]
e = pd.DataFrame({"t": pd.to_datetime(t), "y": y, "p": p}); e["abs"] = (e.y - e.p).abs(); e["hour"] = e.t.dt.hour; e["wk"] = e.t.dt.dayofweek >= 5
e.groupby("hour")["abs"].mean().to_csv(f"{out}/table_mae_by_hour_h1.csv")
R["h1_mae_weekday"] = float(e[~e.wk]["abs"].mean()); R["h1_mae_weekend"] = float(e[e.wk]["abs"].mean())
R["h1_bias_mean_error"] = float((e.p - e.y).mean())
R["test_volume_mean"] = float(e.y.mean()); R["test_volume_max"] = float(e.y.max())

# ---------- importance (h=1) ----------
Dh = build(1); tr, te = split(Dh)
imp = pd.Series(xgb_h1.get_booster().get_score(importance_type="gain")).reindex(FULL).fillna(0); imp = (imp / imp.sum()).sort_values(ascending=False)
imp.to_csv(f"{out}/table_xgb_gain_importance_h1.csv")
samp = te[FULL].sample(2000, random_state=SEED)
sv = shap.TreeExplainer(xgb_h1).shap_values(samp)
shap_imp = pd.Series(np.abs(sv).mean(0), index=FULL).sort_values(ascending=False); shap_imp.to_csv(f"{out}/table_shap_importance_h1.csv")

# ---------- descriptive stats ----------
d = full.dropna(subset=["traffic_volume"])
R["clean_hourly_obs"] = len(d); R["volume_mean"] = float(d.traffic_volume.mean()); R["volume_std"] = float(d.traffic_volume.std())
R["volume_min"] = float(d.traffic_volume.min()); R["volume_max"] = float(d.traffic_volume.max())
R["n_hours_zero_or_near_zero_volume(<50)"] = int((d.traffic_volume < 50).sum())
d.describe().T.to_csv(f"{out}/table_descriptives.csv")
json.dump(R, open(f"{out}/results.json", "w"), indent=2, default=str)

# ---------- figures (Okabe-Ito) ----------
C = dict(blue="#0072B2", orange="#D55E00", green="#009E73", grey="#7F7F7F", black="#222222")
plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False, "font.family": "DejaVu Sans"})
f, ax = plt.subplots(figsize=(6.2, 3.2))
dd = d.assign(h=d.index.hour, wk=d.index.dayofweek >= 5)
for wk, c, lab in ((False, C["blue"], "Weekdays"), (True, C["orange"], "Weekends")):
    s = dd[dd.wk == wk].groupby("h").traffic_volume.mean(); ax.plot(s.index, s.values, color=c, lw=2)
    ax.text(s.index[-1] + .3, s.values[-1], lab, color=C["black"], va="center", fontsize=8)
ax.set_xlabel("Hour of day"); ax.set_ylabel("Mean hourly volume (vehicles/h)"); ax.set_xlim(0, 27); ax.grid(axis="y", alpha=.25)
f.tight_layout(); f.savefig(f"{out}/fig1_daily_profile.png", dpi=300); plt.close(f)

f, ax = plt.subplots(figsize=(6.4, 3.2)); sl = e[(e.t >= "2018-04-02") & (e.t < "2018-04-09")]
ax.plot(sl.t, sl.y, color=C["black"], lw=1.4, label="Observed"); ax.plot(sl.t, sl.p, color=C["orange"], lw=1.2, label="XGBoost (1 h ahead)")
ax.set_ylabel("Volume (vehicles/h)"); ax.legend(frameon=False, fontsize=8); ax.grid(axis="y", alpha=.25)
f.autofmt_xdate(); f.tight_layout(); f.savefig(f"{out}/fig2_week_forecast.png", dpi=300); plt.close(f)

f, ax = plt.subplots(figsize=(6.4, 3.4))
models = ["Seasonal naive (168 h)", "Historical mean (dow x hour)", "Ridge regression", "Random forest", "XGBoost"]
cols = [C["grey"], "#B8B8B8", C["green"], C["blue"], C["orange"]]
w = 0.16
for i, (m, c) in enumerate(zip(models, cols)):
    vals = [res[(res.horizon_h == h) & (res.model == m)].RMSE.iloc[0] for h in HORIZONS]
    ax.bar(np.arange(4) + (i - 2) * w, vals, w * .9, color=c, label=m)
ax.set_xticks(range(4)); ax.set_xticklabels([f"{h} h" for h in HORIZONS]); ax.set_xlabel("Forecast horizon"); ax.set_ylabel("Test RMSE (vehicles/h)")
ax.legend(frameon=False, fontsize=7, ncol=3, loc="upper center", bbox_to_anchor=(0.5, -0.2)); ax.grid(axis="y", alpha=.25)
f.tight_layout(); f.savefig(f"{out}/fig3_rmse_by_horizon.png", dpi=300); plt.close(f)

f, ax = plt.subplots(figsize=(6.0, 3.6)); top = shap_imp.head(10)[::-1]
ax.barh(top.index, top.values, color=C["blue"], height=.6); ax.set_xlabel("Mean |SHAP value| (vehicles/h)")
f.tight_layout(); f.savefig(f"{out}/fig4_shap_importance_h1.png", dpi=300); plt.close(f)

f, ax = plt.subplots(figsize=(6.0, 3.0)); m = e.groupby("hour")["abs"].mean()
ax.bar(m.index, m.values, color=C["orange"], width=.7); ax.set_xlabel("Hour of day (target hour)"); ax.set_ylabel("MAE (vehicles/h)")
ax.grid(axis="y", alpha=.25); f.tight_layout(); f.savefig(f"{out}/fig5_mae_by_hour.png", dpi=300); plt.close(f)
print("done")
