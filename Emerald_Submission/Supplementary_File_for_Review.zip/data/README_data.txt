Dataset: Metro Interstate Traffic Volume (Hogue, 2019), UCI Machine Learning Repository,
doi:10.24432/C5X60B, licence CC BY 4.0. 48,204 rows.
Obtain the original from https://archive.ics.uci.edu/dataset/492/metro+interstate+traffic+volume
and save the CSV as Metro_Interstate_Traffic_Volume.csv.
The file used for the reported results had SHA-256:
749c90d720360a4215bb15345526073c079ba4cc95e3fa558796d083f85fce9e
(a copy obtained from a public GitHub mirror). If your UCI download has a different hash,
confirm the contents are identical (48,204 rows; date_time 2012-10-02 09:00:00 to 2018-09-30 23:00:00)
before comparing results. The data file is not redistributed here.
