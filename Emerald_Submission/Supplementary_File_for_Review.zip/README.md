# Supplementary material for review: traffic volume forecasting with XGBoost

Everything reported in the manuscript comes from `code/run_experiments.py`.

## Contents
- `code/run_experiments.py` - cleaning, features, models, tuning, evaluation, ablation, SHAP, figures.
- `results/` - the output files of the reported run: `results.json` (data-cleaning counts, split sizes,
  selected hyperparameters, bootstrap intervals, seed variation), `table_model_comparison.csv` (Table 2),
  `table_ablation.csv` (Table 4), `table_shap_importance_h1.csv` and `table_xgb_gain_importance_h1.csv`
  (Figure 4), `table_mae_by_hour_h1.csv` (Figure 5), `table_descriptives.csv`, and Figures 1-5 (PNG).
- `data/README_data.txt` - how to obtain the public dataset and its checksum.
- `requirements.txt` - library versions used.

## Reproduce
    python run_experiments.py Metro_Interstate_Traffic_Volume.csv outdir
Create `outdir` first. Run time is roughly 30-40 minutes on a 2-core machine. Random seeds are fixed
(search seed 42; final-model seeds 0-2), but results can differ slightly across library versions or CPUs.

## Protocol summary
Chronological split: forecast targets before 2017-10-01 for training and tuning (4-fold expanding-window
cross-validation), 2017-10-01 to 2018-09-30 for testing. Horizons 1, 3, 6, 24 h, direct strategy.
Search budget: 12 XGBoost and 4 random-forest candidate settings per horizon. Test forecasts are the mean
of three seeds. Bootstrap: moving blocks of 168 h, 500 resamples. Figure 3 (week plot) uses 2-8 April 2018.

## File-to-manuscript figure mapping
fig1_daily_profile.png = Figure 1; fig3_rmse_by_horizon.png = Figure 2; fig2_week_forecast.png = Figure 3;
fig4_shap_importance_h1.png = Figure 4; fig5_mae_by_hour.png = Figure 5.
